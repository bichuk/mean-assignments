export class OrderProduct {
    orderId: string;
    userId: string;
    userName: string;
    productId: string;
    name: string;
    price: number;
    description: string;
    quantity: number;    
}