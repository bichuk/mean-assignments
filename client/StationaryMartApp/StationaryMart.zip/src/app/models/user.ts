export class User {
    _id: string;
    userId: string;
    userName: string;
    password: string;
    userType: string;
}