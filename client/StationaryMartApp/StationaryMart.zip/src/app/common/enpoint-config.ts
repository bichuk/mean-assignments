export class ServerConfig {
    url: String = "http://localhost:8989";
}