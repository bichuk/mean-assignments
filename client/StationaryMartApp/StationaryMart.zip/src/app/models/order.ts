import { OrderProduct } from './order.product';

export class Order {
    // userId: string;
    // oderDate: Date;
    // orderStatus: string;
    // modifiedDate: Date;
    // items: [ProductOrder] 
}